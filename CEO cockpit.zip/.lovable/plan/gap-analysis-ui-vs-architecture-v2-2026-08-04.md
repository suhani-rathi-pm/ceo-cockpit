# Gap analysis — UI vs architecture v2

Everything in boxes 01–03, 05, 07 and most of 08 has a surface already: connectors panel, deterministic engine, four-state board, needs-review queue, lead detail with the arithmetic, news briefing with relevance filter and dismiss, action routing, correction with predicted + corrected state, CRM side, people and roles.

The gaps below are the parts of the schematic that have no UI at all, or only half of one.

## 1. Audit log and observability (box 08, bottom strip) — missing entirely

The schematic calls for one collector surface: connector errors and retries, extraction confidence, news in / surviving / surfaced, every state transition with actor and reason, model call cost and latency, run duration per stage. Today state transitions are only visible per account, and nothing else is visible anywhere.

Proposal: a Settings tab (admin + CEO) with four blocks — run log (stage timings per run), news funnel (ingested → watchlist match → above threshold → shown → dismissed), model calls (purpose, provider, latency, cost), and a full state-transition feed with actor and reason.

## 2. Runtime parameters are read-only (box 04, right rail)

The schematic says "tunable without redeploy". Settings shows the scoring config as a fixed grid. Also `GRANOLA_NOTE_WEIGHT`, `NEWS_RELEVANCE_MIN` and `NEWS_MAX_ITEMS` are not in the config surface at all, and Granola note weight does not exist in the engine.

Proposal: make the parameter grid editable, persisted in `app_settings`, with the values read by the engine and the news filter at run time. Show "changes apply on the next run, history is not re-scored".

## 3. Relevance tuning loop (box N2 / box 07 footer)

"CEO marks an item irrelevant → tunes NEWS_RELEVANCE_MIN" is drawn as a loop. Dismiss currently just hides the item; nothing accumulates and the threshold never moves.

Proposal: record a dismissal with a reason chip (not material / wrong company / duplicate story), show the tally on the News page, and surface a suggested threshold ("6 of your last 10 dismissals scored below 0.62 — raise the floor?") that writes the new value through the parameter store.

## 4. Source trail and extraction confidence (box 03 → box 07 "Lead detail")

Lead detail says "touchpoint history, source trail, attached news, and the arithmetic". The arithmetic and news are there; provenance is not. No row shows which connector produced it, or that a low-confidence extraction was refused.

Proposal: add a source column to the touchpoint table (Notion / Excel / Email / Granola / Document) with extraction confidence where model-derived, plus a short "refused rows" note when a source declined to guess.

## 5. Entity resolution (box 03, marked load-bearing)

"Five sources will name one company five ways" is flagged as the load-bearing step, and open question 1 in the schematic. There is no UI for it — no duplicate-candidate queue, no merge, no alias list.

Proposal: an admin "Possible duplicates" card listing candidate pairs with why they matched and a merge / keep-separate control, plus an alias list per company on the detail page.

## 6. Documents / collateral store (box 04 `documents`)

The store has a `documents` table in the architecture and the source layer ingests decks, rate cards, case studies and RFPs. The app has a CRM "Request collateral" action but nothing that lists what exists or what has been sent.

Proposal: a collateral list on the account detail page (item, type, last updated, sent history) and a fulfilment state on the collateral request.

## 7. Generation cache and provenance (box 04 Redis, box 06)

"Generated once and cached for click-to-play", "TTL 48h · refresh on correction". Briefing, news briefing and audio are produced on view today; nothing shows when they were generated or invalidates them after a correction.

Proposal: persist the generated digest, briefing and audio script per run date, stamp each card with "generated HH:MM from run <date>", and regenerate when a correction lands.

## 8. Outreach drafts (box 06)

The schematic distinguishes internal delegation from client-facing outreach whose opening line is the account-linked news item. Only the internal chief-of-staff brief exists.

Proposal: a second draft mode on the account — client outreach, news-led opening, no pleasantries, Copy / Log as sent.

## 9. Smaller items

- Score runs are "historical, never updated" but there is no run history view — only a yesterday delta.
- Override permissions (open question 2): who may move a state, and whether an override expires, is not expressed in the role card or enforced per role beyond the menu contents.
- Business-unit reply path: routed actions can advance status, but there is no note-back field from the unit for the CEO cross-check step.

## Technical notes

- Parameter tuning belongs in `app_settings` read by `src/lib/scoring.ts` CONFIG and `src/lib/news.constants.ts` at run time, not at module load.
- Observability needs new tables (`run_log`, `model_calls`, `news_funnel`) written by `scoring-run.server.ts`, `news.server.ts` and `handoff.server.ts`; for a prototype these can be seeded plus appended on real runs.
- Source trail needs a `source` and `extraction_confidence` column on `touchpoints`, backfilled in the seed.
- Duplicate candidates can be computed deterministically (normalised name + domain distance) so no model call is needed.

## What I would build first

Items 1, 2 and 3 — they are the parts of the diagram that make the loop demonstrable rather than described. Tell me which of the nine to take and in what order.
