import { useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { Card, CardHead, Empty, Td, Th } from "@/components/cockpit";
import { BTN_GHOST, BTN_PRIMARY } from "@/components/ActionMenu";
import { decideEntityAlias, reopenEntityAlias } from "@/lib/entities.functions";
import type { AliasRow, EntityResolutionData } from "@/lib/entities.server";
import { clearCache } from "@/lib/cache.functions";
import type { CacheStats } from "@/lib/cache.server";

function pct(value: number | null) {
  return value === null ? "—" : `${Math.round(value * 100)}%`;
}

/**
 * Entity resolution queue.
 *
 * Names arrive from upstream systems spelled however the person typed them.
 * The matcher guesses; a human confirms. Nothing joins an account on a guess.
 */
export function EntityQueuePanel({ data, actor }: { data: EntityResolutionData; actor: string }) {
  const router = useRouter();
  const decideFn = useServerFn(decideEntityAlias);
  const reopenFn = useServerFn(reopenEntityAlias);

  const decide = useMutation({
    mutationFn: (input: { id: string; action: "confirm" | "reject"; companyId?: string | null }) =>
      decideFn({ data: { ...input, actor } }),
    onSuccess: async (_r, input) => {
      toast.success(input.action === "confirm" ? "Alias linked" : "Alias rejected", {
        description:
          input.action === "confirm"
            ? "Future mentions of that spelling attach to the account."
            : "That spelling will stay unmatched until someone links it.",
      });
      await router.invalidate();
    },
    onError: (e: Error) => toast.error("Could not save the decision", { description: e.message }),
  });

  const reopen = useMutation({
    mutationFn: (id: string) => reopenFn({ data: { id } }),
    onSuccess: async () => {
      toast.success("Back in the queue");
      await router.invalidate();
    },
    onError: (e: Error) => toast.error("Could not reopen it", { description: e.message }),
  });

  const row = (a: AliasRow) => (
    <tr key={a.id} className="border-b border-border-soft last:border-0">
      <Td>
        <span className="font-medium">{a.alias}</span>
        <span className="figure ml-2 text-[10.5px] text-muted-foreground">{a.source_system}</span>
      </Td>
      <Td>
        <span className="figure text-[11.5px]">{a.occurrences}</span>
      </Td>
      <Td>
        <span className="figure text-[11.5px]">
          {a.confidence === null ? "—" : a.confidence.toFixed(2)}
        </span>
      </Td>
      <Td>
        {a.status === "pending" ? (
          <span className="text-[12.5px] text-ink-2">
            {a.suggested ? a.suggested.name : "No suggestion"}
          </span>
        ) : (
          <span className="text-[12.5px] text-ink-2">
            {a.resolved ? a.resolved.name : "Rejected"}
            {a.resolved_by ? (
              <span className="figure ml-2 text-[10.5px] text-muted-foreground">
                {a.resolved_by}
              </span>
            ) : null}
          </span>
        )}
      </Td>
      <Td>
        {a.status === "pending" ? (
          <div className="flex flex-wrap justify-end gap-1.5">
            <select
              defaultValue={a.suggested?.id ?? ""}
              onChange={(e) =>
                decide.mutate({ id: a.id, action: "confirm", companyId: e.target.value || null })
              }
              className="rounded-[5px] border border-border bg-card px-2 py-[5px] text-[12px]"
              aria-label={`Link ${a.alias} to an account`}
            >
              <option value="">Link to…</option>
              {data.companies.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
            {a.suggested ? (
              <button
                type="button"
                className={BTN_PRIMARY}
                disabled={decide.isPending}
                onClick={() =>
                  decide.mutate({ id: a.id, action: "confirm", companyId: a.suggested!.id })
                }
              >
                Confirm {a.suggested.name}
              </button>
            ) : null}
            <button
              type="button"
              className={BTN_GHOST}
              disabled={decide.isPending}
              onClick={() => decide.mutate({ id: a.id, action: "reject" })}
            >
              Reject
            </button>
          </div>
        ) : (
          <div className="flex justify-end">
            <button
              type="button"
              className={BTN_GHOST}
              disabled={reopen.isPending}
              onClick={() => reopen.mutate(a.id)}
            >
              Put it back
            </button>
          </div>
        )}
      </Td>
    </tr>
  );

  return (
    <Card>
      <CardHead
        title="Names waiting on a person"
        eyebrow="Entity resolution · nothing joins an account on a guess"
        count={data.stats.pending}
      />
      <div className="border-b border-border-soft px-[18px] py-[13px]">
        <p className="figure text-[11.5px] text-muted-foreground">
          {data.stats.pending} pending · {data.stats.confirmed} linked · {data.stats.rejected}{" "}
          rejected · the matcher's suggestion was right {pct(data.stats.suggestion_accuracy)} of the
          time
        </p>
      </div>

      {data.pending.length === 0 ? (
        <Empty
          title="Nothing waiting"
          note="Every incoming name has matched an account or been rejected."
        />
      ) : (
        <table className="w-full">
          <thead>
            <tr className="border-b border-border-soft">
              <Th>Incoming name</Th>
              <Th>Seen</Th>
              <Th>Match</Th>
              <Th>Suggested account</Th>
              <Th className="text-right">Decision</Th>
            </tr>
          </thead>
          <tbody>{data.pending.map(row)}</tbody>
        </table>
      )}

      {data.settled.length > 0 ? (
        <details className="border-t border-border-soft">
          <summary className="cursor-pointer px-[18px] py-[12px] text-[12.5px] font-medium text-ink-2">
            Settled ({data.settled.length})
          </summary>
          <table className="w-full">
            <tbody>{data.settled.map(row)}</tbody>
          </table>
        </details>
      ) : null}
    </Card>
  );
}

/**
 * Generation cache.
 *
 * Cache keys are built from the facts, so the same account on the same run is
 * never paid for twice. Clearing is deliberate, not automatic.
 */
export function CachePanel({ data }: { data: CacheStats }) {
  const router = useRouter();
  const clearFn = useServerFn(clearCache);
  const clear = useMutation({
    mutationFn: (kind: string | undefined) => clearFn({ data: { kind } }),
    onSuccess: async (r) => {
      toast.success("Cache cleared", {
        description: `${r.cleared} entries removed. The next draft is written fresh.`,
      });
      await router.invalidate();
    },
    onError: (e: Error) => toast.error("Could not clear the cache", { description: e.message }),
  });

  return (
    <Card>
      <CardHead
        title="Generation cache"
        eyebrow="Keyed on the facts, not the clock"
        count={data.entries}
      />
      <div className="grid grid-cols-2 gap-x-6 gap-y-4 border-b border-border-soft px-[18px] py-[15px] sm:grid-cols-4">
        {[
          { label: "Entries", value: String(data.entries) },
          { label: "Reuses", value: String(data.hits) },
          { label: "Calls avoided", value: String(data.calls_avoided) },
          { label: "Hit rate", value: pct(data.hit_rate) },
        ].map((f) => (
          <div key={f.label}>
            <div className="eyebrow">{f.label}</div>
            <div className="figure mt-1 text-[19px] font-semibold tracking-[-0.01em]">
              {f.value}
            </div>
          </div>
        ))}
      </div>

      {data.entries === 0 ? (
        <Empty
          title="Nothing cached yet"
          note="Draft a handoff brief or an outreach message and it lands here."
        />
      ) : (
        <table className="w-full">
          <thead>
            <tr className="border-b border-border-soft">
              <Th>Key</Th>
              <Th>Kind</Th>
              <Th>Model</Th>
              <Th className="text-right">Reuses</Th>
            </tr>
          </thead>
          <tbody>
            {data.recent.map((r) => (
              <tr key={r.cache_key} className="border-b border-border-soft last:border-0">
                <Td>
                  <span className="figure text-[11.5px] text-ink-2">{r.cache_key}</span>
                </Td>
                <Td>
                  <span className="text-[12.5px]">{r.kind}</span>
                </Td>
                <Td>
                  <span className="figure text-[11px] text-muted-foreground">{r.model ?? "—"}</span>
                </Td>
                <Td className="text-right">
                  <span className="figure text-[11.5px]">{r.hits}</span>
                </Td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <div className="flex flex-wrap gap-2 border-t border-border-soft px-[18px] py-[14px]">
        <button
          type="button"
          className={BTN_GHOST}
          disabled={clear.isPending || data.entries === 0}
          onClick={() => clear.mutate(undefined)}
        >
          {clear.isPending ? "Clearing…" : "Clear the cache"}
        </button>
        {data.by_kind.map((k) => (
          <button
            key={k.kind}
            type="button"
            className={BTN_GHOST}
            disabled={clear.isPending}
            onClick={() => clear.mutate(k.kind)}
          >
            Clear {k.kind} ({k.entries})
          </button>
        ))}
      </div>
    </Card>
  );
}
