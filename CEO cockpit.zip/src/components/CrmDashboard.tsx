import { Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { AlertBadge, Card, CardHead, Fold, Narrative, Page, PlainBadge } from "@/components/cockpit";
import { CrmAccountTable } from "@/components/CrmAccountTable";
import { StateBadge } from "@/components/StateBadge";
import { getCrmDashboard } from "@/lib/crm.functions";
import type { CrmDashboardData } from "@/lib/crm.server";

/** The account owner's morning read: their book, their instructions, their queue. */
export function CrmDashboard({ crmName }: { crmName: string }) {
  const fn = useServerFn(getCrmDashboard);
  const { data, isPending, error } = useQuery({
    queryKey: ["crm-dashboard", crmName],
    queryFn: () => fn({ data: { crmName } }) as Promise<CrmDashboardData>,
  });

  if (isPending) {
    return (
      <Page>
        <Card>
          <div className="px-[18px] py-[34px] text-center text-[13px] text-muted-foreground">
            Loading your book…
          </div>
        </Card>
      </Page>
    );
  }
  if (error || !data) {
    return (
      <Page>
        <Card>
          <div className="px-[18px] py-[34px] text-center text-[13px] text-muted-foreground">
            Your book could not be loaded. Try refreshing.
          </div>
        </Card>
      </Page>
    );
  }

  const c = data.counters;

  return (
    <Page>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Counter label="My accounts" value={c.accounts} note="Owned on the current run" />
        <Counter
          label="Unread from the CEO"
          value={c.unread}
          note="Each tied to one account"
          to="/messages"
        />
        <Counter label="Open with me" value={c.open_with_me} note="Waiting on you" to="/actions" />
        <Counter
          label="Going cold"
          value={c.going_cold}
          note="No contact in 14 days or more"
          alert={c.going_cold > 0}
        />
      </div>

      <Narrative eyebrow={data.briefing.eyebrow} paragraphs={data.briefing.paragraphs}>
        <p className="figure mt-[18px] border-t border-border-soft pt-3.5 text-[11px] text-muted-foreground">
          {data.briefing.meta}
        </p>
      </Narrative>

      {data.unread_messages.length > 0 ? (
        <Card>
          <CardHead
            title="Unread from the CEO"
            count={data.unread_messages.length}
            eyebrow="Reply from the thread"
          />
          <ul>
            {data.unread_messages.map((m) => (
              <li
                key={m.id}
                className="border-b border-l-[3px] border-l-brand border-border-soft px-[18px] py-3.5 last:border-b-0"
              >
                <div className="mb-1.5 flex flex-wrap items-center gap-2.5">
                  <Link
                    to="/leads/$companyId"
                    params={{ companyId: m.company_id }}
                    className="text-[14px] font-semibold tracking-[-0.005em] hover:text-brand"
                  >
                    {m.company_name}
                  </Link>
                  {m.state ? <StateBadge state={m.state} /> : null}
                  <div className="flex-1" />
                  <span className="figure text-[11px] text-muted-foreground">
                    {new Date(m.created_at).toLocaleString("en-GB", {
                      day: "numeric",
                      month: "short",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </span>
                </div>
                <p className="ai-prose max-w-[74ch] text-[14.5px]">{clip(m.body)}</p>
                <Link
                  to="/messages"
                  className="mt-2.5 inline-block text-[12.5px] font-medium text-brand underline decoration-brand/30 underline-offset-[3px]"
                >
                  Open the thread
                </Link>
              </li>
            ))}
          </ul>
        </Card>
      ) : null}

      {data.pending.length > 0 ? (
        <section className="rounded-md border border-state-alert-border bg-state-alert-wash">
          <div className="flex flex-wrap items-center gap-2.5 border-b border-state-alert-border px-[18px] py-3.5">
            <h3 className="font-display text-[14.5px] font-semibold tracking-[-0.01em]">
              Submitted, waiting on the next run
            </h3>
            <AlertBadge>
              {data.pending.length} item{data.pending.length === 1 ? "" : "s"}
            </AlertBadge>
            <div className="flex-1" />
            <span className="eyebrow">Scored at 04:30</span>
          </div>
          <ul>
            {data.pending.map((p) => (
              <li
                key={p.id}
                className="flex flex-wrap items-center gap-3 border-b border-state-alert-border/60 px-[18px] py-3.5 last:border-0"
              >
                <div className="min-w-0">
                  <span className="text-[14px] font-semibold tracking-[-0.005em]">
                    {p.company_name}
                  </span>
                  <span className="mt-[1px] block text-[11.5px] text-muted-foreground">
                    {p.type} · {p.contact_name || "contact not named"}
                    {p.contact_title ? `, ${p.contact_title}` : ""} · {p.est_opportunity_size} ·{" "}
                    {p.star_rating ? `${p.star_rating} of 5` : "not rated"}
                  </span>
                </div>
                <div className="flex-1" />
                <PlainBadge>{p.occurred_on}</PlainBadge>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <Card>
        <CardHead
          title="Your pipeline accounts"
          count={data.pipeline.length}
          eyebrow="Top of the run, touched in the last 7 days"
        />
        <CrmAccountTable
          rows={data.pipeline}
          actor={crmName}
          emptyTitle="Nothing of yours is in the pipeline band"
          emptyNote="Log a recent touchpoint and the next run can move one up."
        />
      </Card>

      <Fold title="Your opportunity accounts" count={data.opportunity.length} eyebrow="Scored well, gone quiet">
        <CrmAccountTable rows={data.opportunity} actor={crmName} emptyTitle="Nothing here yet" />
      </Fold>

      <Fold title="Your keep-in-touch accounts" count={data.keep_in_touch.length} eyebrow="Steady, not urgent">
        <CrmAccountTable rows={data.keep_in_touch} actor={crmName} emptyTitle="Nothing here yet" />
      </Fold>

      <Fold title="Going cold" count={data.cold.length} eyebrow="No contact in 14 days or more">
        <CrmAccountTable
          rows={data.cold}
          actor={crmName}
          emptyTitle="Nothing is drifting"
          emptyNote="Every account of yours has been touched inside two weeks."
        />
      </Fold>
    </Page>
  );
}

function clip(text: string, max = 220) {
  return text.length <= max ? text : `${text.slice(0, max).trimEnd()}…`;
}

function Counter({
  label,
  value,
  note,
  to,
  alert,
}: {
  label: string;
  value: number;
  note: string;
  to?: "/messages" | "/actions";
  alert?: boolean;
}) {
  const body = (
    <div
      className={`rounded-md border bg-card px-[18px] py-[15px] ${
        alert ? "border-state-alert-border" : "border-border"
      }`}
    >
      <span className="eyebrow block">{label}</span>
      <span className="figure mt-1.5 block text-[27px] font-semibold leading-none tracking-[-0.02em] text-foreground">
        {value}
      </span>
      <span className="mt-1.5 block text-[11.5px] text-muted-foreground">{note}</span>
    </div>
  );
  return to ? (
    <Link to={to} className="block transition-colors hover:opacity-90">
      {body}
    </Link>
  ) : (
    body
  );
}
