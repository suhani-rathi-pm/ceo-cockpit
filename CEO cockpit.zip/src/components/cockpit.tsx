import { useState } from "react";
import { ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Shared surface primitives, matched to the signed-off HTML reference.
 * Every page is built from these so spacing, borders and type stay identical.
 */

export function Page({ children }: { children: React.ReactNode }) {
  return (
    <div className="w-full max-w-[1220px] px-[30px] pb-[70px] pt-7">
      <div className="flex flex-col gap-4">{children}</div>
    </div>
  );
}

export function Card({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={cn("rounded-md border border-border bg-card", className)}>{children}</section>
  );
}

export function CardHead({
  title,
  count,
  eyebrow,
  children,
}: {
  title: string;
  count?: number;
  eyebrow?: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="flex flex-wrap items-center gap-2.5 border-b border-border-soft px-[18px] py-3.5">
      <h3 className="font-display text-[14.5px] font-semibold tracking-[-0.01em]">{title}</h3>
      {count !== undefined ? <Count value={count} /> : null}
      <div className="flex-1" />
      {eyebrow ? <span className="eyebrow">{eyebrow}</span> : null}
      {children}
    </div>
  );
}

export function Count({ value }: { value: number }) {
  return (
    <span className="figure rounded-full bg-border-soft px-[7px] py-0.5 text-[11px] text-muted-foreground">
      {value}
    </span>
  );
}

export function Empty({ title, note }: { title: string; note?: string }) {
  return (
    <div className="px-[18px] py-[34px] text-center text-[13px] text-muted-foreground">
      <b className="mb-1 block font-display text-[14px] font-semibold text-foreground">{title}</b>
      {note}
    </div>
  );
}

/** Collapsible card — the reference's <details class="card fold">. */
export function Fold({
  title,
  count,
  eyebrow,
  children,
  defaultOpen = false,
}: {
  title: string;
  count: number;
  eyebrow?: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <Card>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className={cn(
          "flex w-full flex-wrap items-center gap-2.5 px-[18px] py-3.5 text-left",
          open && "border-b border-border-soft",
        )}
      >
        <ChevronRight
          className={cn(
            "h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-150",
            open && "rotate-90",
          )}
          aria-hidden
        />
        <h3 className="font-display text-[14.5px] font-semibold tracking-[-0.01em]">{title}</h3>
        <Count value={count} />
        <div className="flex-1" />
        {eyebrow ? <span className="eyebrow">{eyebrow}</span> : null}
      </button>
      {open ? children : null}
    </Card>
  );
}

/**
 * Machine-written prose card with the brand-coloured left border.
 * Text is written with **double-asterisk** spans for the brand-wash underline.
 */
export function Narrative({
  eyebrow,
  paragraphs,
  children,
}: {
  eyebrow: string;
  paragraphs: string[];
  children?: React.ReactNode;
}) {
  return (
    <div className="rounded-md border border-border border-l-[3px] border-l-brand bg-card px-[26px] py-[22px]">
      <span className="eyebrow mb-3 block">{eyebrow}</span>
      {paragraphs.map((p, i) => (
        <p
          key={i}
          className="ai-prose mb-[13px] max-w-[74ch] last:mb-0"
        >
          {highlight(p)}
        </p>
      ))}
      {children}
    </div>
  );
}

/** Renders **spans** with the subtle brand-wash underline from the reference. */
export function highlight(text: string) {
  return text.split(/\*\*/).map((part, i) =>
    i % 2 === 1 ? (
      <strong
        key={i}
        className="font-medium [background:linear-gradient(transparent_62%,var(--brand-wash)_62%)]"
      >
        {part}
      </strong>
    ) : (
      <span key={i}>{part}</span>
    ),
  );
}

export function NarrativeFoot({ children }: { children: React.ReactNode }) {
  return (
    <div className="mt-[18px] flex flex-wrap items-center gap-3.5 border-t border-border-soft pt-3.5">
      {children}
    </div>
  );
}

export function Meta({ children }: { children: React.ReactNode }) {
  return <span className="figure text-[11px] text-muted-foreground">{children}</span>;
}

/** Plain neutral pill — used for CRM names, "no rating", state names in history. */
export function PlainBadge({ children }: { children: React.ReactNode }) {
  return (
    <span className="figure inline-flex items-center rounded-full bg-border-soft px-2 py-[3px] text-[10px] font-medium uppercase tracking-[0.06em] text-ink-2">
      {children}
    </span>
  );
}

export function AlertBadge({ children }: { children: React.ReactNode }) {
  return (
    <span className="figure inline-flex items-center rounded-full bg-state-alert px-2 py-[3px] text-[10px] font-medium uppercase tracking-[0.06em] text-state-alert-foreground">
      {children}
    </span>
  );
}

/** Table chrome — mono uppercase heads, soft row rules, hoverable rows. */
export function Th({
  children,
  className,
}: {
  children?: React.ReactNode;
  className?: string;
}) {
  return (
    <th
      className={cn(
        "eyebrow border-b border-border-soft px-3.5 py-[9px] text-left tracking-[0.13em] whitespace-nowrap",
        className,
      )}
    >
      {children}
    </th>
  );
}

export function Td({
  children,
  className,
  colSpan,
}: {
  children?: React.ReactNode;
  className?: string;
  colSpan?: number;
}) {
  return (
    <td
      colSpan={colSpan}
      className={cn("border-b border-border-soft px-3.5 py-[13px] align-middle", className)}
    >
      {children}
    </td>
  );
}

export function ChipButton({
  active,
  children,
  onClick,
}: {
  active: boolean;
  children: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "rounded-[5px] border px-3 py-[6px] text-[12.5px] font-medium transition-colors",
        active
          ? "border-brand bg-brand text-white"
          : "border-border bg-card text-ink-2 hover:border-ink-2/40",
      )}
    >
      {children}
    </button>
  );
}
