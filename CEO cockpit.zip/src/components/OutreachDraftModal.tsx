import { useEffect, useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { Copy, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { draftOutreach, saveOutreach } from "@/lib/outreach.functions";
import type { CollateralItem } from "@/lib/collateral.server";
import type { OutreachChannel } from "@/lib/outreach.server";

const CHANNELS: OutreachChannel[] = ["Email", "LinkedIn"];

/** Client-facing draft, attached to a real piece of collateral. Never sends. */
export function OutreachDraftModal({
  companyId,
  companyName,
  createdBy = "CEO",
  open,
  onOpenChange,
}: {
  companyId: string;
  companyName: string;
  createdBy?: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const router = useRouter();
  const generateFn = useServerFn(draftOutreach);
  const saveFn = useServerFn(saveOutreach);

  const [channel, setChannel] = useState<OutreachChannel>("Email");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [contact, setContact] = useState<string | null>(null);
  const [cached, setCached] = useState(false);
  const [piece, setPiece] = useState<CollateralItem | null>(null);
  const [options, setOptions] = useState<CollateralItem[]>([]);

  const draft = useMutation({
    mutationFn: (input: { channel: OutreachChannel; force: boolean }) =>
      generateFn({ data: { companyId, channel: input.channel, force: input.force } }),
    onSuccess: (d) => {
      setSubject(d.subject);
      setBody(d.body);
      setContact(d.contact_name);
      setCached(d.cached);
      setPiece(d.collateral);
      setOptions(d.suggested_collateral);
    },
    onError: (e: Error) => toast.error("Could not write the draft", { description: e.message }),
  });

  const saved = useMutation({
    mutationFn: () =>
      saveFn({
        data: {
          companyId,
          channel,
          contactName: contact,
          subject,
          body,
          collateralId: piece?.id ?? null,
          createdBy,
        },
      }),
    onSuccess: async () => {
      toast.success("Draft saved", {
        description: `Held against ${companyName} as a draft. Approve it when you are happy with it.`,
      });
      onOpenChange(false);
      await router.invalidate();
    },
    onError: (e: Error) => toast.error("Could not save the draft", { description: e.message }),
  });

  useEffect(() => {
    if (open && !subject && !draft.isPending) draft.mutate({ channel: "Email", force: false });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Draft outreach — {companyName}</DialogTitle>
          <DialogDescription>
            Written from this account's own record and the collateral we actually have. Nothing is
            sent from this app.
            {cached
              ? " Reused from the generation cache — the facts have not changed since it was written."
              : ""}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="flex flex-wrap items-end gap-3">
            <div className="space-y-1.5">
              <Label>Channel</Label>
              <div className="flex gap-1.5">
                {CHANNELS.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => {
                      setChannel(c);
                      draft.mutate({ channel: c, force: false });
                    }}
                    className={
                      c === channel
                        ? "rounded-[5px] bg-brand px-3 py-[6px] text-[12.5px] font-medium text-white"
                        : "rounded-[5px] border border-border px-3 py-[6px] text-[12.5px] font-medium text-ink-2 hover:border-ink-2/40"
                    }
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
            <div className="min-w-[180px] flex-1 space-y-1.5">
              <Label htmlFor="outreach-contact">To</Label>
              <Input
                id="outreach-contact"
                value={contact ?? ""}
                onChange={(e) => setContact(e.target.value || null)}
                placeholder="Contact name"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="outreach-subject">
              {channel === "LinkedIn" ? "Opening line" : "Subject"}
            </Label>
            <Input
              id="outreach-subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder={draft.isPending ? "Writing…" : ""}
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="outreach-body">Message</Label>
            <Textarea
              id="outreach-body"
              value={body}
              onChange={(e) => setBody(e.target.value)}
              rows={12}
              placeholder={draft.isPending ? "Writing from the account record…" : ""}
            />
          </div>

          {options.length > 0 ? (
            <div className="space-y-1.5">
              <Label>Attach collateral</Label>
              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={() => setPiece(null)}
                  className={
                    piece === null
                      ? "rounded-[5px] bg-brand px-2.5 py-[5px] text-[12px] font-medium text-white"
                      : "rounded-[5px] border border-border px-2.5 py-[5px] text-[12px] text-ink-2 hover:border-ink-2/40"
                  }
                >
                  Nothing attached
                </button>
                {options.map((o) => (
                  <button
                    key={o.id}
                    type="button"
                    onClick={() => setPiece(o)}
                    className={
                      piece?.id === o.id
                        ? "rounded-[5px] bg-brand px-2.5 py-[5px] text-[12px] font-medium text-white"
                        : "rounded-[5px] border border-border px-2.5 py-[5px] text-[12px] text-ink-2 hover:border-ink-2/40"
                    }
                  >
                    {o.kind} · {o.title}
                  </button>
                ))}
              </div>
            </div>
          ) : null}
        </div>

        <DialogFooter className="flex-wrap gap-2 sm:justify-between">
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => draft.mutate({ channel, force: true })}
              disabled={draft.isPending}
            >
              <RefreshCw className="h-3.5 w-3.5" aria-hidden />
              {draft.isPending ? "Writing…" : "Rewrite"}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={async () => {
                await navigator.clipboard.writeText(`${subject}\n\n${body}`);
                toast.success("Draft copied");
              }}
              disabled={!body}
            >
              <Copy className="h-3.5 w-3.5" aria-hidden />
              Copy
            </Button>
          </div>
          <Button
            size="sm"
            onClick={() => saved.mutate()}
            disabled={saved.isPending || !subject.trim() || !body.trim()}
          >
            {saved.isPending ? "Saving…" : "Save the draft"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
