import { Link } from "@tanstack/react-router";
import { useAuth } from "@/components/AuthProvider";
import { Wordmark } from "@/components/LoginScreen";
import { ROLE_LABEL, initialsOf, navFor } from "@/lib/roles";

export function AppSidebar() {
  const { user, signOut } = useAuth();
  if (!user) return null;
  const { label, items } = navFor(user.role);

  return (
    <aside className="sticky top-0 flex h-screen w-[236px] shrink-0 flex-col gap-[26px] bg-shell px-3.5 py-5 text-shell-foreground">
      <div className="px-1.5">
        <Wordmark className="w-[176px]" />
        <div className="mt-2 font-display text-[15px] font-semibold text-[#F0F4F5]">
          Cockpit
          <span className="ml-2 font-mono text-[9.5px] font-normal uppercase tracking-[0.14em] text-[#6C7F8C]">
            CEO layer
          </span>
        </div>
      </div>

      <nav className="flex flex-col gap-0.5">
        <div className="mb-1.5 mt-3.5 px-2.5 font-mono text-[9.5px] uppercase tracking-[0.14em] text-[#6C7F8C]">
          {label}
        </div>
        {items.map(({ to, label: text, icon: Icon, count }) => (
          <Link
            key={to}
            to={to}
            activeOptions={{ exact: to === "/" }}
            className="flex items-center gap-2.5 rounded-[5px] px-2.5 py-2 text-[13.5px] font-medium text-[#B4C2CB] transition-colors hover:bg-[#1E2C3A] hover:text-[#EAF0F2]"
            activeProps={{ className: "bg-brand text-white hover:bg-brand hover:text-white" }}
          >
            <Icon className="size-[15px] shrink-0" strokeWidth={1.7} />
            <span>{text}</span>
            {count ? (
              <span className="ml-auto font-mono text-[10.5px] opacity-70">{count}</span>
            ) : null}
          </Link>
        ))}
      </nav>

      <div className="mt-auto border-t border-shell-line pt-3.5">
        <div className="flex items-center gap-[9px] px-1.5">
          <div className="grid size-7 shrink-0 place-items-center rounded-full bg-[#2A3A49] text-[11px] font-semibold text-[#DCE5E9]">
            {initialsOf(user.name)}
          </div>
          <div>
            <b className="block text-[12.5px] font-semibold leading-tight text-[#E4EBEE]">
              {user.name}
            </b>
            <span className="font-mono text-[10.5px] uppercase tracking-[0.06em] text-shell-muted">
              {ROLE_LABEL[user.role]}
            </span>
          </div>
        </div>
        <button
          type="button"
          onClick={signOut}
          className="mt-3 w-full rounded-md border border-shell-line py-[7px] text-[12.5px] font-semibold text-[#9EB0BB] transition-colors hover:bg-[#1E2C3A] hover:text-[#E4EBEE]"
        >
          Sign out
        </button>
      </div>
    </aside>
  );
}
