import { Link } from "@tanstack/react-router";
import { ActionMenu } from "@/components/ActionMenu";
import { Empty, Td, Th } from "@/components/cockpit";
import { StateBadge } from "@/components/StateBadge";
import type { DashboardRow } from "@/lib/dashboard.server";

/**
 * The one lead table shape used on the dashboard.
 *
 * Deliberately reduced: no score and no score composition. The maths is
 * computed in the back end and shown only on the account page, where there is
 * room to show its working.
 */
export function LeadTable({ rows, showRank = false }: { rows: DashboardRow[]; showRank?: boolean }) {
  if (rows.length === 0) {
    return (
      <Empty
        title="Nothing here today"
        note="No accounts match this band in the current run."
      />
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[760px] border-collapse">
        <thead>
          <tr>
            {showRank ? <Th>#</Th> : null}
            <Th>Company</Th>
            <Th>State</Th>
            <Th>Tier</Th>
            <Th>Last touch</Th>
            <Th>Owner</Th>
            <Th />
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={row.company_id} className="transition-colors last:[&>td]:border-b-0 hover:bg-[#F8FAFA]">
              {showRank ? (
                <Td className="figure w-[26px] text-[12px] text-muted-foreground">{row.rank ?? i + 1}</Td>
              ) : null}
              <Td>
                <Link
                  to="/leads/$companyId"
                  params={{ companyId: row.company_id }}
                  className="block"
                >
                  <span className="text-[14px] font-semibold tracking-[-0.005em] hover:text-brand">
                    {row.name}
                  </span>
                  {row.news_count > 0 ? (
                    <span className="figure ml-2 rounded-[3px] bg-brand-wash px-1.5 py-0.5 text-[9.5px] font-medium uppercase tracking-[0.08em] text-brand">
                      News
                    </span>
                  ) : null}
                  <span className="mt-[1px] block text-[11.5px] text-muted-foreground">
                    {row.industry ?? "Industry unknown"} · ICP {row.icp_fit} ·{" "}
                    {row.touchpoint_count} touchpoint{row.touchpoint_count === 1 ? "" : "s"}
                  </span>
                </Link>
              </Td>
              <Td>
                <StateBadge state={row.state} />
              </Td>
              <Td className="figure text-[12.5px] whitespace-nowrap">{row.tier_label ?? "—"}</Td>
              <Td className="figure text-[12.5px] whitespace-nowrap">
                {row.days_since_last_touchpoint === null
                  ? "—"
                  : `${row.days_since_last_touchpoint}d`}
              </Td>
              <Td className="figure text-[12.5px] whitespace-nowrap">
                {row.owner_crm ?? "Unassigned"}
              </Td>
              <Td className="text-right">
                <ActionMenu
                  companyId={row.company_id}
                  companyName={row.name}
                  currentState={row.state}
                  owner={row.owner_crm}
                />
              </Td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
