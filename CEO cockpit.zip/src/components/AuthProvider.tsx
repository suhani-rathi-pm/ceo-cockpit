import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { USERS, type CockpitUser, type Role } from "@/lib/roles";

type AuthValue = {
  user: CockpitUser | null;
  ready: boolean;
  signIn: (user: CockpitUser) => void;
  signOut: () => void;
  /** Live "View as" switch — swaps the identity without signing out. */
  viewAs: (role: Role) => void;
};

const AuthContext = createContext<AuthValue | null>(null);
const STORAGE_KEY = "cockpit.user.id";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<CockpitUser | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const id = window.localStorage.getItem(STORAGE_KEY);
    const found = id ? USERS.find((u) => u.id === id) : undefined;
    if (found) setUser(found);
    setReady(true);
  }, []);

  const value = useMemo<AuthValue>(
    () => ({
      user,
      ready,
      signIn: (next) => {
        window.localStorage.setItem(STORAGE_KEY, next.id);
        setUser(next);
      },
      signOut: () => {
        window.localStorage.removeItem(STORAGE_KEY);
        setUser(null);
      },
      viewAs: (role) => {
        const next = USERS.find((u) => u.role === role);
        if (!next) return;
        window.localStorage.setItem(STORAGE_KEY, next.id);
        setUser(next);
      },
    }),
    [user, ready],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
