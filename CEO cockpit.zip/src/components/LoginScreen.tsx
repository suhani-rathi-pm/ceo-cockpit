import { useState } from "react";
import { useAuth } from "@/components/AuthProvider";
import logoAsset from "@/assets/programming-logo.png.asset.json";
import wordmarkAsset from "@/assets/programming-wordmark.png.asset.json";
import { ROLE_LABEL, USERS, WORK_DOMAIN, findUserByEmail } from "@/lib/roles";

const SHORTCUTS = [
  { email: "ishwari@programming.com", blurb: "Sees the full board, every account, all controls" },
  { email: "priya@programming.com", blurb: "Sees only the accounts she owns" },
  { email: "devika@programming.com", blurb: "Manages people and roles" },
];

export function LoginScreen() {
  const { signIn } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  function submit() {
    const em = email.trim().toLowerCase();
    if (!em.endsWith(WORK_DOMAIN)) {
      setError("That address is outside Programming.com. Sign in with your work account.");
      return;
    }
    const found = findUserByEmail(em);
    if (!found) {
      setError("No Cockpit account for that address yet. Ask a super admin to add you.");
      return;
    }
    setError(null);
    signIn(found);
  }

  return (
    <div className="grid min-h-screen bg-shell lg:grid-cols-[1.05fr_.95fr]">
      {/* Brand panel */}
      <div className="relative hidden flex-col justify-between overflow-hidden px-[60px] py-14 lg:flex bg-[radial-gradient(120%_90%_at_8%_0%,#1E2C3B_0%,rgba(30,44,59,0)_60%),linear-gradient(180deg,#16202C_0%,#0E1720_100%)]">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 opacity-[0.28] [background-image:linear-gradient(#2A3846_1px,transparent_1px),linear-gradient(90deg,#2A3846_1px,transparent_1px)] [background-size:64px_64px] [mask-image:radial-gradient(90%_70%_at_20%_30%,#000_0%,transparent_75%)]"
        />
        <div className="relative z-10 flex items-center gap-3.5">
          <Wordmark className="w-[188px]" />
          <div className="border-l border-[#2A3846] pl-3.5">
            <div className="font-display text-base font-semibold text-[#F0F4F5]">Cockpit</div>
            <div className="font-mono text-[10px] uppercase tracking-[0.14em] text-[#7D909C]">
              CEO intelligence layer
            </div>
          </div>
        </div>

        <div className="relative z-10 max-w-[30ch]">
          <h1 className="mb-[18px] font-display text-[clamp(30px,3.6vw,46px)] font-bold leading-[1.03] tracking-[-0.03em] text-[#E8EDEF]">
            What needs you today, before anyone asks.
          </h1>
          <p className="font-serif text-[17px] leading-[1.55] text-[#B6C4CD]">
            Every touchpoint across Notion, Excel, email, calls and collateral — scored on fixed
            rules, classified into four states, and read in two minutes.
          </p>
        </div>

        <div className="relative z-10 flex flex-wrap gap-[34px]">
          {[
            { n: "6", l: "Connected sources" },
            { n: "140", l: "Touchpoints scored" },
            { n: "04:30", l: "Run completes" },
          ].map((s) => (
            <div key={s.l}>
              <b className="figure block font-display text-[21px] font-semibold text-[#E8EDEF]">
                {s.n}
              </b>
              <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-[#7D909C]">
                {s.l}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Sign-in panel */}
      <div className="grid place-items-center bg-background px-7 py-10">
        <div className="w-full max-w-[380px]">
          <h2 className="mb-1.5 font-display text-[23px] font-semibold tracking-[-0.02em]">
            Sign in
          </h2>
          <p className="mb-[26px] text-[13.5px] text-muted-foreground">
            Use your Programming.com account. Access is scoped to your role.
          </p>

          {error ? (
            <div className="mb-3.5 rounded-md border border-[#EFCFC9] bg-state-alert px-3 py-2.5 text-[12.5px] text-[#7E2A20]">
              {error}
            </div>
          ) : null}

          <form
            onSubmit={(e) => {
              e.preventDefault();
              submit();
            }}
          >
            <Field label="Work email">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@programming.com"
                autoComplete="username"
                className="w-full rounded-md border border-border bg-card px-3 py-2.5 text-sm outline-none focus:border-brand focus:ring-[3px] focus:ring-brand-wash"
              />
            </Field>
            <Field label="Password">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                autoComplete="current-password"
                className="w-full rounded-md border border-border bg-card px-3 py-2.5 text-sm outline-none focus:border-brand focus:ring-[3px] focus:ring-brand-wash"
              />
            </Field>
            <button
              type="submit"
              className="w-full rounded-md bg-brand px-4 py-[11px] text-[13.5px] font-semibold text-white transition-colors hover:bg-brand-ink"
            >
              Sign in
            </button>
          </form>

          <div className="eyebrow my-[26px] mb-4 flex items-center gap-3 before:h-px before:flex-1 before:bg-border before:content-[''] after:h-px after:flex-1 after:bg-border after:content-['']">
            Prototype shortcuts
          </div>

          <div className="flex flex-col gap-[7px]">
            {SHORTCUTS.map((s) => {
              const u = USERS.find((x) => x.email === s.email);
              if (!u) return null;
              return (
                <button
                  key={s.email}
                  type="button"
                  onClick={() => signIn(u)}
                  className="flex items-center justify-between gap-2.5 rounded-md border border-border bg-card px-3 py-2.5 text-left transition-colors hover:border-brand"
                >
                  <span>
                    <b className="block text-[13px] font-semibold">{u.name}</b>
                    <span className="text-[11.5px] text-muted-foreground">{s.blurb}</span>
                  </span>
                  <span className="shrink-0 rounded-[3px] bg-secondary px-[7px] py-[3px] font-mono text-[9.5px] uppercase tracking-[0.1em] text-ink-2">
                    {ROLE_LABEL[u.role]}
                  </span>
                </button>
              );
            })}
          </div>

          <p className="mt-[18px] text-[11.5px] leading-[1.5] text-muted-foreground">
            Front-end prototype. Sign-in is simulated — no account is created and nothing is sent.
            Only <b className="font-semibold">@programming.com</b> addresses are accepted.
          </p>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="mb-[15px] block">
      <span className="eyebrow mb-1.5 block">{label}</span>
      {children}
    </label>
  );
}

export function BrandMark() {
  return (
    <div className="grid size-9 shrink-0 place-items-center overflow-hidden rounded-lg bg-[#131628]">
      <img src={logoAsset.url} alt="" aria-hidden className="w-[74px] max-w-none" />
    </div>
  );
}

/** Full Programming.com wordmark on its own navy plate. */
export function Wordmark({ className = "" }: { className?: string }) {
  return (
    <span className={`inline-block overflow-hidden rounded-md bg-[#131628] ${className}`}>
      <img src={wordmarkAsset.url} alt="Programming.com" className="block w-full" />
    </span>
  );
}
