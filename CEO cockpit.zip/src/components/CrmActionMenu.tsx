import { useState } from "react";
import { ChevronDown, Star } from "lucide-react";
import { useNavigate, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { BTN_GHOST, BTN_PRIMARY } from "@/components/ActionMenu";
import { COLLATERAL_ITEMS, OPPORTUNITY_SIZES } from "@/lib/crm.constants";
import { askForCollateral, flagUp, markInactive, reviseSize } from "@/lib/crm.functions";
import { cn } from "@/lib/utils";

/**
 * The account owner's action menu. Deliberately different from the CEO's:
 * an owner can log, revise, flag up, ask for collateral and mark inactive.
 * They cannot correct a classification, mark an account lost, or email the
 * chief of staff — those stay with the CEO.
 */

export type CrmActionKind = "log" | "revise" | "flag" | "collateral" | "inactive";

export const CRM_ACTION_LABEL: Record<CrmActionKind, string> = {
  log: "Log a touchpoint",
  revise: "Revise the opportunity size",
  flag: "Flag for Ishwari",
  collateral: "Request collateral",
  inactive: "Mark inactive",
};

export const FIELD =
  "w-full rounded-[5px] border border-border bg-card px-2.5 py-[7px] text-[13px] text-foreground outline-none focus:border-brand";

export function FieldLabel({ htmlFor, children }: { htmlFor: string; children: React.ReactNode }) {
  return (
    <label htmlFor={htmlFor} className="eyebrow mb-[6px] block tracking-[0.11em]">
      {children}
    </label>
  );
}

/** Five stars, click to set. Disabled for email, which is never rated. */
export function StarPicker({
  value,
  onChange,
  disabled,
}: {
  value: number | null;
  onChange: (v: number) => void;
  disabled?: boolean;
}) {
  return (
    <div className="flex items-center gap-1.5" aria-disabled={disabled}>
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          disabled={disabled}
          onClick={() => onChange(n)}
          aria-label={`${n} star${n === 1 ? "" : "s"}`}
          className={cn(
            "rounded-[4px] p-[3px] transition-colors",
            disabled ? "cursor-not-allowed opacity-40" : "hover:bg-border-soft",
          )}
        >
          <Star
            className={cn(
              "h-[17px] w-[17px]",
              value !== null && n <= value ? "fill-brand text-brand" : "text-border",
            )}
            strokeWidth={1.6}
          />
        </button>
      ))}
      <span className="figure ml-1 text-[11px] text-muted-foreground">
        {disabled ? "Not rated" : value ? `${value} of 5` : "No rating yet"}
      </span>
    </div>
  );
}

function Shell({
  open,
  onClose,
  title,
  submitLabel,
  pending,
  disabled,
  onSubmit,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  submitLabel: string;
  pending: boolean;
  disabled?: boolean;
  onSubmit: () => void;
  children: React.ReactNode;
}) {
  return (
    <Dialog open={open} onOpenChange={(o) => (o ? undefined : onClose())}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-[15.5px] font-semibold tracking-[-0.01em]">
            {title}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">{children}</div>
        <DialogFooter>
          <button type="button" className={BTN_GHOST} onClick={onClose}>
            Cancel
          </button>
          <button
            type="button"
            className={BTN_PRIMARY}
            onClick={onSubmit}
            disabled={pending || disabled}
          >
            {pending ? "Saving…" : submitLabel}
          </button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ReviseModal({
  companyId,
  companyName,
  actor,
  open,
  onClose,
}: {
  companyId: string;
  companyName: string;
  actor: string;
  open: boolean;
  onClose: () => void;
}) {
  const router = useRouter();
  const [size, setSize] = useState<string>(OPPORTUNITY_SIZES[1]);
  const [changed, setChanged] = useState("");
  const fn = useServerFn(reviseSize);
  const m = useMutation({
    mutationFn: () => fn({ data: { companyId, actor, newSize: size, whatChanged: changed } }),
    onSuccess: async () => {
      toast.success(`${companyName} revised to ${size}`, {
        description: "Enters scoring at the 04:30 run.",
      });
      setChanged("");
      onClose();
      await router.invalidate();
    },
    onError: (e: Error) => toast.error("Could not revise the size", { description: e.message }),
  });

  return (
    <Shell
      open={open}
      onClose={onClose}
      title={`Revise the opportunity size — ${companyName}`}
      submitLabel="Save the revision"
      pending={m.isPending}
      disabled={!changed.trim()}
      onSubmit={() => m.mutate()}
    >
      <div>
        <FieldLabel htmlFor="revise-size">New opportunity size</FieldLabel>
        <select
          id="revise-size"
          className={FIELD}
          value={size}
          onChange={(e) => setSize(e.target.value)}
        >
          {OPPORTUNITY_SIZES.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>
      <div>
        <FieldLabel htmlFor="revise-changed">What changed</FieldLabel>
        <textarea
          id="revise-changed"
          rows={4}
          className={FIELD}
          value={changed}
          onChange={(e) => setChanged(e.target.value)}
        />
      </div>
    </Shell>
  );
}

function FlagModal({
  companyId,
  companyName,
  actor,
  open,
  onClose,
}: {
  companyId: string;
  companyName: string;
  actor: string;
  open: boolean;
  onClose: () => void;
}) {
  const router = useRouter();
  const [body, setBody] = useState("");
  const fn = useServerFn(flagUp);
  const m = useMutation({
    mutationFn: () => fn({ data: { companyId, actor, body } }),
    onSuccess: async () => {
      toast.success(`Flagged ${companyName} for Ishwari`, {
        description: "It surfaces on her actions queue and in her next briefing.",
      });
      setBody("");
      onClose();
      await router.invalidate();
    },
    onError: (e: Error) => toast.error("Could not send the flag", { description: e.message }),
  });

  return (
    <Shell
      open={open}
      onClose={onClose}
      title={`Flag for Ishwari — ${companyName}`}
      submitLabel="Send it up"
      pending={m.isPending}
      disabled={!body.trim()}
      onSubmit={() => m.mutate()}
    >
      <div>
        <FieldLabel htmlFor="flag-body">What she needs to know</FieldLabel>
        <textarea
          id="flag-body"
          rows={5}
          className={FIELD}
          value={body}
          onChange={(e) => setBody(e.target.value)}
        />
      </div>
    </Shell>
  );
}

function CollateralModal({
  companyId,
  companyName,
  actor,
  open,
  onClose,
}: {
  companyId: string;
  companyName: string;
  actor: string;
  open: boolean;
  onClose: () => void;
}) {
  const router = useRouter();
  const [item, setItem] = useState<string>(COLLATERAL_ITEMS[0]);
  const [neededBy, setNeededBy] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    return d.toISOString().slice(0, 10);
  });
  const [note, setNote] = useState("");
  const fn = useServerFn(askForCollateral);
  const m = useMutation({
    mutationFn: () => fn({ data: { companyId, actor, item, neededBy, note } }),
    onSuccess: async () => {
      toast.success(`${item} requested for ${companyName}`, {
        description: `Needed by ${neededBy}.`,
      });
      setNote("");
      onClose();
      await router.invalidate();
    },
    onError: (e: Error) => toast.error("Could not send the request", { description: e.message }),
  });

  return (
    <Shell
      open={open}
      onClose={onClose}
      title={`Request collateral — ${companyName}`}
      submitLabel="Request it"
      pending={m.isPending}
      onSubmit={() => m.mutate()}
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <FieldLabel htmlFor="coll-item">What you need</FieldLabel>
          <select
            id="coll-item"
            className={FIELD}
            value={item}
            onChange={(e) => setItem(e.target.value)}
          >
            {COLLATERAL_ITEMS.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
        <div>
          <FieldLabel htmlFor="coll-date">Needed by</FieldLabel>
          <input
            id="coll-date"
            type="date"
            className={FIELD}
            value={neededBy}
            onChange={(e) => setNeededBy(e.target.value)}
          />
        </div>
      </div>
      <div>
        <FieldLabel htmlFor="coll-note">Context</FieldLabel>
        <textarea
          id="coll-note"
          rows={3}
          className={FIELD}
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
      </div>
    </Shell>
  );
}

function InactiveModal({
  companyId,
  companyName,
  actor,
  open,
  onClose,
}: {
  companyId: string;
  companyName: string;
  actor: string;
  open: boolean;
  onClose: () => void;
}) {
  const router = useRouter();
  const [reason, setReason] = useState("");
  const fn = useServerFn(markInactive);
  const m = useMutation({
    mutationFn: () => fn({ data: { companyId, actor, reason } }),
    onSuccess: async () => {
      toast.success(`${companyName} marked inactive`, {
        description: "It drops out of the board at the next run, with the reason attached.",
      });
      setReason("");
      onClose();
      await router.invalidate();
    },
    onError: (e: Error) => toast.error("Could not mark it inactive", { description: e.message }),
  });

  return (
    <Shell
      open={open}
      onClose={onClose}
      title={`Mark inactive — ${companyName}`}
      submitLabel="Mark it inactive"
      pending={m.isPending}
      disabled={!reason.trim()}
      onSubmit={() => m.mutate()}
    >
      <div>
        <FieldLabel htmlFor="inactive-reason">Reason</FieldLabel>
        <textarea
          id="inactive-reason"
          rows={4}
          className={FIELD}
          value={reason}
          onChange={(e) => setReason(e.target.value)}
        />
      </div>
    </Shell>
  );
}

export function CrmActionMenu({
  companyId,
  companyName,
  actor,
  variant = "ghost",
}: {
  companyId: string;
  companyName: string;
  actor: string;
  variant?: "ghost" | "primary";
}) {
  const navigate = useNavigate();
  const [which, setWhich] = useState<CrmActionKind | null>(null);
  const kinds: CrmActionKind[] = ["log", "revise", "flag", "collateral", "inactive"];

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button type="button" className={variant === "primary" ? BTN_PRIMARY : BTN_GHOST}>
            Action
            <ChevronDown className="h-3.5 w-3.5" aria-hidden />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-64">
          <DropdownMenuLabel className="eyebrow font-normal">{companyName}</DropdownMenuLabel>
          {kinds.slice(0, 4).map((k) => (
            <DropdownMenuItem
              key={k}
              className="text-[13px]"
              onSelect={() => {
                if (k === "log") {
                  void navigate({ to: "/log-activity", search: { account: companyId } });
                  return;
                }
                setWhich(k);
              }}
            >
              {CRM_ACTION_LABEL[k]}
            </DropdownMenuItem>
          ))}
          <DropdownMenuSeparator />
          <DropdownMenuItem
            className="text-[13px] text-destructive focus:text-destructive"
            onSelect={() => setWhich("inactive")}
          >
            {CRM_ACTION_LABEL["inactive"]}
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <ReviseModal
        companyId={companyId}
        companyName={companyName}
        actor={actor}
        open={which === "revise"}
        onClose={() => setWhich(null)}
      />
      <FlagModal
        companyId={companyId}
        companyName={companyName}
        actor={actor}
        open={which === "flag"}
        onClose={() => setWhich(null)}
      />
      <CollateralModal
        companyId={companyId}
        companyName={companyName}
        actor={actor}
        open={which === "collateral"}
        onClose={() => setWhich(null)}
      />
      <InactiveModal
        companyId={companyId}
        companyName={companyName}
        actor={actor}
        open={which === "inactive"}
        onClose={() => setWhich(null)}
      />
    </>
  );
}
