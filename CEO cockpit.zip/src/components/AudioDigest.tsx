import { useEffect, useRef, useState } from "react";
import { Pause, Play, Square, Volume2 } from "lucide-react";
import type { DigestScript } from "@/lib/digest.server";

/**
 * Inline click-to-play spoken briefing using the browser's built-in Web Speech API.
 * No paid TTS service — this is the POC-appropriate path, and it keeps the
 * script visible as text so it can be reviewed without listening.
 */
export function AudioDigest({ digest }: { digest: DigestScript }) {
  const [supported, setSupported] = useState(true);
  const [status, setStatus] = useState<"idle" | "playing" | "paused">("idle");
  const [showScript, setShowScript] = useState(false);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    setSupported(typeof window !== "undefined" && "speechSynthesis" in window);
    return () => {
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // A fresh script invalidates anything mid-flight.
  useEffect(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    setStatus("idle");
  }, [digest.spoken_text]);

  function play() {
    const synth = window.speechSynthesis;
    if (status === "paused") {
      synth.resume();
      setStatus("playing");
      return;
    }
    synth.cancel();
    const utterance = new SpeechSynthesisUtterance(digest.spoken_text);
    utterance.rate = 1;
    utterance.pitch = 1;
    utterance.onend = () => setStatus("idle");
    utterance.onerror = () => setStatus("idle");
    utteranceRef.current = utterance;
    synth.speak(utterance);
    setStatus("playing");
  }

  function pause() {
    window.speechSynthesis.pause();
    setStatus("paused");
  }

  function stop() {
    window.speechSynthesis.cancel();
    setStatus("idle");
  }

  const minutes = Math.floor(digest.estimated_seconds / 60);
  const seconds = digest.estimated_seconds % 60;
  const length = minutes > 0 ? `${minutes}m ${seconds}s` : `${seconds}s`;

  return (
    <>
      <div className="flex flex-wrap items-center gap-3.5">
        {supported ? (
          <>
            <button
              type="button"
              onClick={status === "playing" ? pause : play}
              className="inline-flex items-center gap-1.5 rounded-[5px] bg-brand px-3 py-[6px] text-[12.5px] font-medium text-white transition-colors hover:bg-brand-ink"
              aria-label={status === "playing" ? "Pause audio digest" : "Play audio digest"}
            >
              {status === "playing" ? (
                <>
                  <Pause className="h-3.5 w-3.5" aria-hidden /> Pause
                </>
              ) : (
                <>
                  <Play className="h-3.5 w-3.5" aria-hidden />
                  {status === "paused" ? "Resume audio digest" : "Play audio digest"}
                </>
              )}
            </button>
            {status !== "idle" ? (
              <button
                type="button"
                onClick={stop}
                className="inline-flex items-center gap-1.5 rounded-[5px] border border-border bg-card px-3 py-[6px] text-[12.5px] font-medium text-ink-2 hover:border-ink-2/40"
                aria-label="Stop audio digest"
              >
                <Square className="h-3.5 w-3.5" aria-hidden /> Stop
              </button>
            ) : null}
          </>
        ) : (
          <span className="flex items-center gap-1.5 text-[11.5px] text-muted-foreground">
            <Volume2 className="h-3.5 w-3.5" aria-hidden />
            Speech playback isn&apos;t available in this browser — read the script instead.
          </span>
        )}

        <button
          type="button"
          onClick={() => setShowScript((v) => !v)}
          className="figure text-[11px] text-muted-foreground underline decoration-border underline-offset-[3px] hover:text-foreground"
        >
          {showScript ? "Hide script" : "Read the script"}
        </button>

        <span className="figure text-[11px] text-muted-foreground">
          ~{length} · {digest.word_count} words
          {digest.trimmed ? " · trimmed to fit 90 seconds" : ""}
        </span>
      </div>

      {showScript ? (
        <div className="mt-3.5 space-y-3 rounded-md border border-border-soft bg-[#F8FAFA] px-4 py-3.5">
          {digest.paragraphs.map((p) => (
            <div key={p.heading}>
              <span className="eyebrow">{p.heading}</span>
              <p className="mt-1 text-[13px] leading-[1.6] text-ink-2">{p.text}</p>
            </div>
          ))}
        </div>
      ) : null}
    </>
  );
}
