import { useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { StateBadge } from "@/components/StateBadge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { correctClassification } from "@/lib/lead.functions";
import type { CompanyState } from "@/lib/scoring";

const ACTORS = ["Rep", "VP", "CEO"] as const;

/** Lost is never assigned by the engine — only here, by a human, with a reason. */
export function MarkLostModal({
  companyId,
  companyName,
  predictedState,
  open,
  onOpenChange,
}: {
  companyId: string;
  companyName: string;
  predictedState: CompanyState | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const router = useRouter();
  const [actor, setActor] = useState<string>("CEO");
  const [reason, setReason] = useState("");
  const correctFn = useServerFn(correctClassification);

  const mutation = useMutation({
    mutationFn: () =>
      correctFn({ data: { companyId, toState: "Lost", actor, reason: reason.trim() } }),
    onSuccess: async () => {
      toast.success("Marked as Lost", {
        description: `${companyName} · ${actor} · system prediction kept on record.`,
      });
      setReason("");
      onOpenChange(false);
      await router.invalidate();
    },
    onError: (e: Error) => toast.error("Could not mark as Lost", { description: e.message }),
  });

  const reasonMissing = reason.trim().length === 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Mark as Lost — {companyName}</DialogTitle>
          <DialogDescription>
            Logged as a human transition to Lost. The system's own prediction is preserved.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-sm">
            <span className="text-muted-foreground">Current state</span>
            {predictedState ? (
              <StateBadge state={predictedState} />
            ) : (
              <span className="text-muted-foreground">unclassified</span>
            )}
            <span aria-hidden className="text-muted-foreground">
              →
            </span>
            <StateBadge state="Lost" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="lost-actor">Actor</Label>
            <Select value={actor} onValueChange={setActor}>
              <SelectTrigger id="lost-actor">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {ACTORS.map((a) => (
                  <SelectItem key={a} value={a}>
                    {a}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="lost-reason">
              Reason <span className="text-destructive">*</span>
            </Label>
            <Textarea
              id="lost-reason"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Why is this account lost?"
              rows={3}
              required
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            variant="destructive"
            onClick={() => mutation.mutate()}
            disabled={mutation.isPending || reasonMissing}
            title={reasonMissing ? "A reason is required" : undefined}
          >
            {mutation.isPending ? "Saving…" : "Mark as Lost"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
