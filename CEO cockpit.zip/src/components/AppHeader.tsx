import { ClientOnly } from "@tanstack/react-router";
import { useAuth } from "@/components/AuthProvider";
import { ROLE_LABEL, USERS, type Role } from "@/lib/roles";

function TodayDate() {
  const today = new Date().toLocaleDateString("en-GB", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
  return <span className="font-mono text-[11.5px] tracking-[0.03em] text-muted-foreground">{today}</span>;
}

/** Live role switch — swaps identity without signing out. */
function ViewAs() {
  const { user, viewAs } = useAuth();
  const options: Role[] = ["ceo", "crm", "admin"];
  return (
    <div className="flex items-center gap-[7px]">
      <label htmlFor="view-as" className="eyebrow tracking-[0.12em]">
        View as
      </label>
      <select
        id="view-as"
        value={user?.role ?? "ceo"}
        onChange={(e) => viewAs(e.target.value as Role)}
        className="rounded-[5px] border border-border bg-card px-2 py-[5px] text-[12.5px]"
      >
        {options.map((r) => {
          const u = USERS.find((x) => x.role === r);
          return (
            <option key={r} value={r}>
              {u ? `${u.name.split(" ")[0]} — ${ROLE_LABEL[r]}` : ROLE_LABEL[r]}
            </option>
          );
        })}
      </select>
    </div>
  );
}

export function AppHeader({ title }: { title: string }) {
  return (
    <header className="sticky top-0 z-20 flex h-[58px] items-center gap-4 border-b border-border bg-card px-[30px]">
      <h1 className="font-display text-[16.5px] font-semibold tracking-[-0.015em]">{title}</h1>
      <div className="flex-1" />
      <ClientOnly fallback={<span className="h-4 w-40" aria-hidden />}>
        <ViewAs />
        <TodayDate />
      </ClientOnly>
    </header>
  );
}

/** Thin dark strip above the top bar. */
export function PrototypeStrip() {
  return (
    <div className="flex items-center gap-4 bg-shell-deep px-[30px] py-1.5 font-mono text-[10.5px] uppercase tracking-[0.09em] text-[#93A5B0]">
      <b className="font-medium text-[#D5DEE3]">Prototype</b>
      <span>Seeded data · front end only · no live connectors</span>
    </div>
  );
}
