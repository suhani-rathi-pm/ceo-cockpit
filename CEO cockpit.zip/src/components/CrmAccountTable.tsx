import { Link } from "@tanstack/react-router";
import { CrmActionMenu } from "@/components/CrmActionMenu";
import { Empty, Td, Th } from "@/components/cockpit";
import { StateBadge } from "@/components/StateBadge";
import type { CrmAccountRow } from "@/lib/crm.server";

/** The owner's account table. Same reduced column set as the CEO's — no score. */
export function CrmAccountTable({
  rows,
  actor,
  emptyTitle = "Nothing here",
  emptyNote,
}: {
  rows: CrmAccountRow[];
  actor: string;
  emptyTitle?: string;
  emptyNote?: string;
}) {
  if (rows.length === 0) {
    return emptyNote ? <Empty title={emptyTitle} note={emptyNote} /> : <Empty title={emptyTitle} />;
  }


  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[720px] border-collapse text-[13.5px]">
        <thead>
          <tr>
            <Th className="w-[52px]">Rank</Th>
            <Th>Account</Th>
            <Th className="w-[132px]">State</Th>
            <Th className="w-[96px]">Tier</Th>
            <Th className="w-[112px]">Last logged</Th>
            <Th className="w-[104px]" />
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.company_id} className="transition-colors hover:bg-[#F7F8F8]">
              <Td className="figure text-[12px] text-muted-foreground">{row.rank ?? "—"}</Td>
              <Td>
                <Link
                  to="/leads/$companyId"
                  params={{ companyId: row.company_id }}
                  className="block min-w-0"
                >
                  <span className="text-[14px] font-semibold tracking-[-0.005em] hover:text-brand">
                    {row.name}
                  </span>
                  <span className="mt-[1px] block text-[11.5px] text-muted-foreground">
                    {row.industry ?? "Industry unknown"} · ICP {row.icp_fit} ·{" "}
                    {row.touchpoint_count} touchpoint{row.touchpoint_count === 1 ? "" : "s"}
                  </span>
                </Link>
              </Td>
              <Td>
                <StateBadge state={row.state} />
              </Td>
              <Td className="figure text-[11px] text-muted-foreground">
                {row.tier_label ?? "—"}
              </Td>
              <Td className="figure text-[12px] text-muted-foreground">
                {row.days_since_last_touchpoint === null
                  ? "never"
                  : `${row.days_since_last_touchpoint}d ago`}
              </Td>
              <Td className="text-right">
                <CrmActionMenu
                  companyId={row.company_id}
                  companyName={row.name}
                  actor={actor}
                />
              </Td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
