import { useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { BUSINESS_UNITS } from "@/lib/actions.constants";
import { createAction } from "@/lib/lead.functions";

export function ActionModal({
  companyId,
  companyName,
  open,
  onOpenChange,
}: {
  companyId: string;
  companyName: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const router = useRouter();
  const [unit, setUnit] = useState<string>(BUSINESS_UNITS[0]);
  const [note, setNote] = useState("");
  const actionFn = useServerFn(createAction);

  const mutation = useMutation({
    mutationFn: () => actionFn({ data: { companyId, routedTo: unit, note } }),
    onSuccess: async () => {
      toast.success("Action created", {
        description: `${companyName} routed to ${unit} · status Open.`,
      });
      setNote("");
      onOpenChange(false);
      await router.invalidate();
    },
    onError: (e: Error) => toast.error("Could not create action", { description: e.message }),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Route action — {companyName}</DialogTitle>
          <DialogDescription>
            Hands this account to a business unit. Creates an open item on the Actions page.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="action-unit">Business unit</Label>
            <Select value={unit} onValueChange={setUnit}>
              <SelectTrigger id="action-unit">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {BUSINESS_UNITS.map((u) => (
                  <SelectItem key={u} value={u}>
                    {u}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="action-note">Note (optional)</Label>
            <Textarea
              id="action-note"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Context for whoever picks this up…"
              rows={3}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={() => mutation.mutate()} disabled={mutation.isPending}>
            {mutation.isPending ? "Confirming…" : "Confirm"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
