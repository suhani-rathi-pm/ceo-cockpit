import { useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { StateBadge } from "@/components/StateBadge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { correctClassification } from "@/lib/lead.functions";
import type { CompanyState } from "@/lib/scoring";

const STATES: CompanyState[] = ["Pipeline", "Opportunity", "Keep in touch", "Lost"];
const ACTORS = ["Rep", "VP", "CEO"] as const;

export function CorrectClassificationModal({
  companyId,
  companyName,
  predictedState,
  open,
  onOpenChange,
}: {
  companyId: string;
  companyName: string;
  predictedState: CompanyState | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const router = useRouter();
  const [toState, setToState] = useState<string>(predictedState ?? "Pipeline");
  const [actor, setActor] = useState<string>("CEO");
  const [reason, setReason] = useState("");
  const correctFn = useServerFn(correctClassification);

  const mutation = useMutation({
    mutationFn: () =>
      correctFn({
        data: { companyId, toState: toState as CompanyState, actor, reason: reason.trim() },
      }),
    onSuccess: async () => {
      toast.success("Classification corrected", {
        description: `${actor} overrode ${predictedState ?? "unclassified"} → ${toState}. Original prediction kept.`,
      });
      setReason("");
      onOpenChange(false);
      await router.invalidate();
    },
    onError: (e: Error) => toast.error("Could not save correction", { description: e.message }),
  });

  const reasonMissing = reason.trim().length === 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Correct classification — {companyName}</DialogTitle>
          <DialogDescription>
            The system prediction is kept alongside your correction so model accuracy stays
            measurable.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-sm">
            <span className="text-muted-foreground">System predicted</span>
            {predictedState ? (
              <StateBadge state={predictedState} />
            ) : (
              <span className="text-muted-foreground">unclassified</span>
            )}
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="correct-state">New state</Label>
            <Select value={toState} onValueChange={setToState}>
              <SelectTrigger id="correct-state">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {STATES.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="correct-actor">Actor</Label>
            <Select value={actor} onValueChange={setActor}>
              <SelectTrigger id="correct-actor">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {ACTORS.map((a) => (
                  <SelectItem key={a} value={a}>
                    {a}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="correct-reason">
              Reason <span className="text-destructive">*</span>
            </Label>
            <Textarea
              id="correct-reason"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Why is the system wrong here?"
              rows={3}
              required
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            onClick={() => mutation.mutate()}
            disabled={mutation.isPending || reasonMissing}
            title={reasonMissing ? "A reason is required" : undefined}
          >
            {mutation.isPending ? "Saving…" : "Save correction"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
