import { useEffect, useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { Copy, Mail, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { generateHandoff, logHandoff } from "@/lib/handoff.functions";

export function HandoffEmailModal({
  companyId,
  companyName,
  open,
  onOpenChange,
}: {
  companyId: string;
  companyName: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const router = useRouter();
  const generateFn = useServerFn(generateHandoff);
  const logFn = useServerFn(logHandoff);

  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [recipient, setRecipient] = useState("");
  const [cached, setCached] = useState(false);

  const draft = useMutation({
    mutationFn: (force: boolean) => generateFn({ data: { companyId, force } }),
    onSuccess: (d) => {
      setCached(d.cached);
      setSubject(d.subject);
      setBody(d.body);
      setRecipient(d.recipient);
    },
    onError: (e: Error) => toast.error("Could not draft the handoff", { description: e.message }),
  });

  const logged = useMutation({
    mutationFn: () => logFn({ data: { companyId, subject, body } }),
    onSuccess: async () => {
      toast.success("Handoff logged", {
        description: `${companyName} recorded as an email handoff on the Actions page. Nothing was sent.`,
      });
      onOpenChange(false);
      await router.invalidate();
    },
    onError: (e: Error) => toast.error("Could not log the handoff", { description: e.message }),
  });

  // Generate on open, once.
  useEffect(() => {
    if (open && !subject && !draft.isPending) draft.mutate(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const mailto = `mailto:${encodeURIComponent(recipient)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Handoff to Chief of Staff — {companyName}</DialogTitle>
          <DialogDescription>
            Internal delegation brief, AI-drafted from today's run. Prototype: nothing is sent from
            this app — "Log as sent" only records the handoff.
            {cached ? " This brief was reused from the generation cache — the facts have not changed since it was written." : ""}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label>To</Label>
            <p className="rounded-md border border-border bg-muted/40 px-3 py-2 text-sm">
              Chief of Staff · {recipient || "loading…"}
              <span className="ml-2 text-xs text-muted-foreground">(set in Settings)</span>
            </p>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="handoff-subject">Subject</Label>
            <Input
              id="handoff-subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder={draft.isPending ? "Drafting…" : ""}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="handoff-body">Body</Label>
            <Textarea
              id="handoff-body"
              value={body}
              onChange={(e) => setBody(e.target.value)}
              rows={14}
              placeholder={draft.isPending ? "Drafting from today's score run…" : ""}
              className="font-normal"
            />
          </div>
        </div>

        <DialogFooter className="flex-wrap gap-2 sm:justify-between">
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => draft.mutate(true)}
              disabled={draft.isPending}
            >
              <RefreshCw className="h-3.5 w-3.5" aria-hidden />
              {draft.isPending ? "Drafting…" : "Regenerate"}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={async () => {
                await navigator.clipboard.writeText(`Subject: ${subject}\n\n${body}`);
                toast.success("Draft copied");
              }}
              disabled={!body}
            >
              <Copy className="h-3.5 w-3.5" aria-hidden />
              Copy
            </Button>
            <Button variant="outline" size="sm" asChild disabled={!body}>
              <a href={mailto}>
                <Mail className="h-3.5 w-3.5" aria-hidden />
                Open in mail client
              </a>
            </Button>
          </div>
          <Button
            size="sm"
            onClick={() => logged.mutate()}
            disabled={logged.isPending || !subject.trim() || !body.trim()}
          >
            {logged.isPending ? "Logging…" : "Log as sent"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
