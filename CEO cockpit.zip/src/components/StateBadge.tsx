import { cn } from "@/lib/utils";

const STATE_STYLES: Record<string, string> = {
  Pipeline: "bg-state-pipeline text-state-pipeline-foreground",
  Opportunity: "bg-state-opportunity text-state-opportunity-foreground",
  "Keep in touch": "bg-state-keep text-state-keep-foreground",
  Lost: "bg-state-lost text-state-lost-foreground",
};

/** One badge shape for company state, everywhere in the app. */
export function StateBadge({ state, className }: { state: string; className?: string }) {
  return (
    <span
      className={cn(
        "figure inline-flex items-center rounded-full px-2 py-[3px] text-[10px] font-medium uppercase tracking-[0.06em] whitespace-nowrap",
        STATE_STYLES[state] ?? STATE_STYLES["Lost"],
        className,
      )}
    >
      {state}
    </span>
  );
}
