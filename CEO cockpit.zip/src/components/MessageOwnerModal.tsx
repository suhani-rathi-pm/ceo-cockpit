import { useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { messageOwner } from "@/lib/actions.functions";

/**
 * Direct note to the CRM who owns the relationship. Nothing is sent from the
 * prototype — the message is logged as an open item against the account.
 */
export function MessageOwnerModal({
  companyId,
  companyName,
  owner,
  open,
  onOpenChange,
}: {
  companyId: string;
  companyName: string;
  owner: string | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const router = useRouter();
  const [body, setBody] = useState("");
  const send = useServerFn(messageOwner);

  const mutation = useMutation({
    mutationFn: () => send({ data: { companyId, owner: owner ?? "Unassigned", body } }),
    onSuccess: async () => {
      toast.success("Message logged", {
        description: `${owner ?? "The owner"} will see it against ${companyName} on the Actions page. Nothing was sent.`,
      });
      setBody("");
      onOpenChange(false);
      await router.invalidate();
    },
    onError: (e: Error) => toast.error("Could not log the message", { description: e.message }),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Message {owner ?? "the account owner"}</DialogTitle>
          <DialogDescription>
            About {companyName}. Say what you want done and by when. Prototype — the message is
            logged as an open item, not delivered.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-1.5">
          <Label htmlFor="owner-note">Message</Label>
          <Textarea
            id="owner-note"
            value={body}
            onChange={(e) => setBody(e.target.value)}
            rows={7}
            placeholder="What you want them to do, and by when"
          />
        </div>

        <DialogFooter>
          <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button size="sm" onClick={() => mutation.mutate()} disabled={!body.trim() || mutation.isPending}>
            {mutation.isPending ? "Logging…" : "Send"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
