import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { ActionModal } from "@/components/ActionModal";
import { CorrectClassificationModal } from "@/components/CorrectClassificationModal";
import { HandoffEmailModal } from "@/components/HandoffEmailModal";
import { MarkLostModal } from "@/components/MarkLostModal";
import { MessageOwnerModal } from "@/components/MessageOwnerModal";
import { OutreachDraftModal } from "@/components/OutreachDraftModal";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import type { ActionKind } from "@/lib/recommendation";
import type { CompanyState } from "@/lib/scoring";
import { cn } from "@/lib/utils";

export type { ActionKind };

export interface ActionTarget {
  companyId: string;
  companyName: string;
  currentState: CompanyState | null;
  owner?: string | null;
}

/** Every human action on an account, in one place. */
export function ActionModals({
  target,
  which,
  onClose,
}: {
  target: ActionTarget;
  which: ActionKind | null;
  onClose: () => void;
}) {
  const { companyId, companyName, currentState, owner = null } = target;
  return (
    <>
      <ActionModal
        companyId={companyId}
        companyName={companyName}
        open={which === "route"}
        onOpenChange={(o) => (o ? undefined : onClose())}
      />
      {which === "email" ? (
        <HandoffEmailModal
          companyId={companyId}
          companyName={companyName}
          open
          onOpenChange={(o) => (o ? undefined : onClose())}
        />
      ) : null}
      {which === "outreach" ? (
        <OutreachDraftModal
          companyId={companyId}
          companyName={companyName}
          open
          onOpenChange={(o) => (o ? undefined : onClose())}
        />
      ) : null}
      <MessageOwnerModal
        companyId={companyId}
        companyName={companyName}
        owner={owner}
        open={which === "note"}
        onOpenChange={(o) => (o ? undefined : onClose())}
      />
      <CorrectClassificationModal
        companyId={companyId}
        companyName={companyName}
        predictedState={currentState}
        open={which === "correct"}
        onOpenChange={(o) => (o ? undefined : onClose())}
      />
      <MarkLostModal
        companyId={companyId}
        companyName={companyName}
        predictedState={currentState}
        open={which === "lost"}
        onOpenChange={(o) => (o ? undefined : onClose())}
      />
    </>
  );
}

export const ACTION_LABEL: Record<ActionKind, string> = {
  email: "Email the chief of staff",
  outreach: "Draft outreach to the account",
  note: "Message the account owner",
  route: "Route to a business unit",
  correct: "Correct the classification",
  lost: "Mark as lost",
};

const BTN =
  "inline-flex items-center gap-1.5 rounded-[5px] px-3 py-[6px] text-[12.5px] font-medium transition-colors disabled:opacity-50";
export const BTN_PRIMARY = `${BTN} bg-brand text-white hover:bg-brand-ink`;
export const BTN_GHOST = `${BTN} border border-border bg-card text-ink-2 hover:border-ink-2/40`;

/** Dropdown "Action" control used from every table row and the detail header. */
export function ActionMenu({
  companyId,
  companyName,
  currentState,
  owner = null,
  variant = "ghost",
}: {
  companyId: string;
  companyName: string;
  currentState: CompanyState | null;
  owner?: string | null;
  variant?: "ghost" | "primary";
}) {
  const [which, setWhich] = useState<ActionKind | null>(null);
  const kinds: ActionKind[] = ["email", "outreach", "note", "route", "correct", "lost"];

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button type="button" className={variant === "primary" ? BTN_PRIMARY : BTN_GHOST}>
            Action
            <ChevronDown className="h-3.5 w-3.5" aria-hidden />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-64">
          <DropdownMenuLabel className="eyebrow font-normal">{companyName}</DropdownMenuLabel>
          {kinds.slice(0, 4).map((k) => (
            <DropdownMenuItem key={k} onSelect={() => setWhich(k)} className="text-[13px]">
              {ACTION_LABEL[k]}
            </DropdownMenuItem>
          ))}
          <DropdownMenuSeparator />
          {kinds.slice(4).map((k) => (
            <DropdownMenuItem
              key={k}
              onSelect={() => setWhich(k)}
              className={cn("text-[13px]", k === "lost" && "text-destructive focus:text-destructive")}
            >
              {ACTION_LABEL[k]}
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>

      <ActionModals
        target={{ companyId, companyName, currentState, owner }}
        which={which}
        onClose={() => setWhich(null)}
      />
    </>
  );
}
