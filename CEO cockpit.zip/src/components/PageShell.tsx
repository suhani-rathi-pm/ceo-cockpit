/** Placeholder body for pages that are shells until we fill them in. */
export function PageShell({
  eyebrow,
  title,
  note,
}: {
  eyebrow: string;
  title: string;
  note: string;
}) {
  return (
    <div className="w-full max-w-[1220px] px-[30px] pb-[70px] pt-7">
      <div className="rounded-md border border-border bg-card p-[26px]">
        <span className="eyebrow mb-3 block">{eyebrow}</span>
        <h2 className="font-display text-[19px] font-semibold tracking-[-0.02em]">{title}</h2>
        <p className="mt-2 text-[13.5px] text-muted-foreground">{note}</p>
      </div>
    </div>
  );
}
